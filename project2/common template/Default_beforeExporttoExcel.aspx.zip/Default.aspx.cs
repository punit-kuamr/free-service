﻿using Gvkdata;
using GvkEmriRjis.Bll;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Bind_District();
            // // Get_Gps_Penalty();

            //string script = "$(document).ready(function () { $('[id*=btnSubmit]').click(); });";
            //ClientScript.RegisterStartupScript(this.GetType(), "load", script, true);

            Bind_FortNight();
        }
    }

    private void Bind_District()
    {
        //ddlDistrict
        try
        {
            Common clsCommon = new Common();
            DataTable Dist = new DataTable();
            Dist = clsCommon.getdistrict();
            ddlDistrict.DataSource = Dist;
            ddlDistrict.DataTextField = "dname";
            ddlDistrict.DataValueField = "did";
            ddlDistrict.DataBind();
        }
        catch (Exception ex)
        {
            ErrorHandler.ErrorsEntry(ex.ToString(), "Default.aspx || Bind_District()" + DateTime.Now, " " + Session["user_name"].ToString());

        }
    }

    public void Bind_FortNight()
    {
        try
        {
            Common clsCommon = new Common();
            DataTable FortNight = new DataTable();
            FortNight = clsCommon.getFortNight();
            ddlfortNight.DataSource = FortNight;
            ddlfortNight.DataTextField = "fortnight";
            ddlfortNight.DataValueField = "id";
            ddlfortNight.DataBind();
        }
        catch (Exception ex)
        {
 ErrorHandler.ErrorsEntry(ex.ToString(), "Default.aspx || Bind_FortNight()" + DateTime.Now, " " + Session["user_name"].ToString());

        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        

    }


    public void caliculateGpsPenality(string id)
    {
        try
        {
            // Panel1.Visible = true;
            Common clsCommon = new Common();
            MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["GvkEmriCon"].ToString());
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            conn.Open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conn;
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Get_Gps_Penalty";
            cmd.Parameters.AddWithValue("id", ddlfortNight.SelectedValue);
            adp.Fill(ds);
            dt = ds.Tables[0];
            int count = 0, days = 0, Amount = 1000, Penalty = 0;
            string vehicle1, vehicle2, vehicle;
            string startDate = System.DateTime.Now.ToString("dd-MM-yyyy"), EndDate = System.DateTime.Now.ToString("dd-MM-yyyy");
            DataTable dtNew = new DataTable();
            dtNew.Columns.Add(new DataColumn("Ambulance No.", typeof(string)));
            dtNew.Columns.Add(new DataColumn("District Name", typeof(string)));
            dtNew.Columns.Add(new DataColumn("Start Date", typeof(string)));
            dtNew.Columns.Add(new DataColumn("End Date", typeof(string)));
            dtNew.Columns.Add(new DataColumn("Days", typeof(int)));
            dtNew.Columns.Add(new DataColumn("Penalty", typeof(int)));
            count = 1;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                vehicle1 = dt.Rows[i]["vehicle_no"].ToString();

                if (i != 0)
                {
                    if (count == 1)
                    {
                        startDate = Convert.ToDateTime(dt.Rows[i - 1]["missing_date"].ToString()).ToString("dd-MM-yyyy");
                    }
                    vehicle2 = dt.Rows[i - 1]["vehicle_no"].ToString();
                    DateTime d = Convert.ToDateTime(dt.Rows[i]["missing_date"].ToString());
                    DateTime d2 = Convert.ToDateTime(dt.Rows[i - 1]["missing_date"].ToString()).AddDays(1);
                    if (vehicle1 == vehicle2 && Convert.ToDateTime(dt.Rows[i]["missing_date"].ToString()) == Convert.ToDateTime(dt.Rows[i - 1]["missing_date"].ToString()).AddDays(1))
                    {
                        count = count + 1;
                    }
                    else
                    {
                        if (count > 2)
                        {
                            days = count;
                            vehicle = vehicle2;
                            Penalty = Amount * count;
                            string vehicle_no = vehicle2;
                            string district_name = dt.Rows[i - 1]["district_name"].ToString();
                            int Days = days;
                            EndDate = Convert.ToDateTime(dt.Rows[i - 1]["missing_date"].ToString()).ToString("dd-MM-yyyy");
                            dtNew.Rows.Add(vehicle_no, district_name, startDate, EndDate, days, Penalty);
                            count = 1;
                        }
                        else
                        {
                            count = 1;
                        }
                    }
                }
                if (i == dt.Rows.Count - 1 && count > 2)
                {
                    days = count;
                    vehicle = vehicle2 = dt.Rows[i]["vehicle_no"].ToString(); ;
                    Penalty = Amount * count;
                    string vehicle_no = vehicle2;
                    string district_name = dt.Rows[i]["district_name"].ToString();
                    int Days = days;
                    EndDate = Convert.ToDateTime(dt.Rows[i]["missing_date"].ToString()).ToString("dd-MM-yyyy");
                    dtNew.Rows.Add(vehicle_no, district_name, startDate, EndDate, days, Penalty);
                    count = 1;
                }
            }
            if (dtNew.Rows.Count > 0)
            {

                for (int i = 0; i < dtNew.Rows.Count; i++)
                {
                    clsCommon.UpdateDataGpsPenality(dtNew.Rows[i]["Ambulance No."].ToString(), dtNew.Rows[i]["Penalty"].ToString(), id);
                }
            }
            else
            {
                //  grdPenalty.DataSource = null;
                //  grdPenalty.DataBind();
                //  lblPenalty.Text = "0";
            }
            // ImageButton1.Enabled = true;
        }
        catch (Exception ex)
        {
ErrorHandler.ErrorsEntry(ex.ToString(), "Default.aspx || caliculateGpsPenality()" + DateTime.Now, " " + Session["user_name"].ToString());

        }

    }
    private void caliculateschpenality(string id)
    {
        Common clsCommon = new Common();
        MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["GvkEmriCon"].ToString());
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();
        MySqlCommand cmd = new MySqlCommand();
        cmd.Connection = conn;
        MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "Get_Oil_Change_Penalty";
        cmd.Parameters.AddWithValue("id", id);
        adp.Fill(ds);
        dt = ds.Tables[0];
        if (dt.Rows.Count > 0)
        {

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                clsCommon.UpdateDataschPenality(dt.Rows[i]["Ambulance No."].ToString(), dt.Rows[i]["Penalty"].ToString(), id);
            }

        }
        else
        {
            //grdPenalty.DataSource = null;
            //grdPenalty.DataBind();
            //lblPenalty.Text = "0";
        }
    }

    private void caliculateInspectionPenality(string id)
    {
        Common clsCommon = new Common();
        MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["GvkEmriCon"].ToString());
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();
        MySqlCommand cmd = new MySqlCommand();
        cmd.Connection = conn;
        MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "Get_Vehicle_Inspection_Penalty";
        cmd.Parameters.AddWithValue("id", id);
        adp.Fill(ds);
        dt = ds.Tables[0];
        if (dt.Rows.Count > 0)
        {

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                clsCommon.UpdateDataInspectionPenality(dt.Rows[i]["Ambulance No."].ToString(), dt.Rows[i]["Penalty"].ToString(), id);
            }

        }
        else
        {
            //grdPenalty.DataSource = null;
            //grdPenalty.DataBind();
            //lblPenalty.Text = "0";
        }

    }

    private void CaliculateRtPenality(string id)
    {
        Common clsCommon = new Common();
        MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["GvkEmriCon"].ToString());
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        conn.Open();
        MySqlCommand cmd = new MySqlCommand();
        cmd.Connection = conn;
        MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "Get_Vehicle_Response_Time_Penality";
        cmd.Parameters.AddWithValue("id", id);
        adp.Fill(ds);
        dt = ds.Tables[0];
        if (dt.Rows.Count > 0)
        {

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                int amount = Convert.ToInt32(dt.Rows[i]["Penalty"].ToString());
                if (amount > 0)
                {
                    clsCommon.UpdateDataRTPenality(dt.Rows[i]["Ambulance No."].ToString(), amount.ToString(), id);
                }
            }

        }
        else
        {
            //grdPenalty.DataSource = null;
            //grdPenalty.DataBind();
            //lblPenalty.Text = "0";
        }


    }

    private void bindData(string id, string dist)
    {

        Common clsCommon = new Common();
        DataTable dtData = new DataTable();
        dtData = clsCommon.getData_penality(id, dist);
        if (dtData.Rows.Count <= 0)
        {
            lblStatus.Text = "Data is Not processed to this fortnight/District. Please process the data first";
        }
        lblStatus.Text = "";
        grdData.DataSource = dtData;
        grdData.DataBind();
    }

    protected void grdData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        grdData.PageIndex = e.NewPageIndex;
        bindData(ddlfortNight.SelectedItem.Value.ToString(), ddlDistrict.SelectedItem.Value.ToString());
    }

    protected void btnPush_Click(object sender, EventArgs e)
    {
        try
        {
            Gvkdata.WS_InsertGVKdata GVK = new Gvkdata.WS_InsertGVKdata();
            Gvkdata.response R = new Gvkdata.response();
            Common clsCommon = new Common();
            DataTable dtData = new DataTable();
            dtData = clsCommon.getData_penality_all(ddlfortNight.SelectedItem.Value.ToString(), ddlDistrict.SelectedItem.Value.ToString());
            if (dtData.Rows.Count <= 0)
            {
                lblStatus.Text = "Data is Not processed to this fortnight/District. Please process the data first";
            }

            else
            {
                response[] emps = new response[] {
            new response()
            {
                status = R.status,
                statusMess=R.statusMess,
                TrnsID=R.TrnsID,
                //parameters=resss(billnumber,requestid,receiptnumber)
            }
        };
                for (int i = 0; i < dtData.Rows.Count; i++)
                {
                    string sno = dtData.Rows[i]["sno"].ToString();
                    int rtp = Convert.ToInt32(dtData.Rows[i]["responsetimePeality"].ToString());
                    int avltp = Convert.ToInt32(dtData.Rows[i]["avltPenality"].ToString());
                    int schp = Convert.ToInt32(dtData.Rows[i]["scheduledpeality"].ToString()); 
                    int insppen = Convert.ToInt32(dtData.Rows[i]["vehicleinspectionapppenality"].ToString());
                    int sum = rtp + avltp + insppen + schp;
                    string vehtype = dtData.Rows[i]["vehtypeid"].ToString();
		    ErrorHandler.ErrorsEntry("", "Data Submitted -- waiting for response" + DateTime.Now, " " + Session["user_name"].ToString());
                    emps = GVK.InsertGvkData(dtData.Rows[i]["RoleIID"].ToString(), dtData.Rows[i]["year"].ToString(), dtData.Rows[i]["month"].ToString(), dtData.Rows[i]["fortnighid"].ToString(),
                          dtData.Rows[i]["nhmdistId"].ToString(), dtData.Rows[i]["vehtypeid"].ToString(), dtData.Rows[i]["vehicleid"].ToString(),
                           dtData.Rows[i]["vehiclenumber"].ToString(), dtData.Rows[i]["billingAmount"].ToString(), rtp.ToString(),
                           insppen.ToString(), avltp.ToString(), dtData.Rows[i]["scheduledpeality"].ToString(), dtData.Rows[i]["ProportionalDeduction"].ToString(), sum.ToString(), dtData.Rows[i]["LoginD"].ToString());
			ErrorHandler.ErrorsEntry("", "Response Received" + DateTime.Now, " " + Session["user_name"].ToString());
                    string st = emps[0].status.ToString();
                    string msg = emps[0].statusMess.ToString();
                    string tid = emps[0].TrnsID.ToString();

                    if (st == "1")
                    {
                        clsCommon.updateTxn(sno, tid, Session["user_name"].ToString());
                    }
                    else
                    {
                        clsCommon.insertFailedTxn(st, msg, tid, sno);
                    }


                }

                dtData = null;
                grdData.DataSource = dtData;
                grdData.DataBind();
                dtData = clsCommon.getData_penality(ddlfortNight.SelectedItem.Value.ToString(), ddlDistrict.SelectedItem.Value.ToString());
                grdData.DataSource = dtData;
                grdData.DataBind();


            }
        }
        catch (Exception ex)
        {

			ErrorHandler.ErrorsEntry(ex.ToString(), "Default.aspx || btnPush_Click()" + DateTime.Now, " " + Session["user_name"].ToString());
        }

    }

    protected void btnBindData_Click(object sender, EventArgs e)
    {
        if (ddlfortNight.SelectedIndex <= 0)
        {
            lblStatus.Text = "Please select Fortnight ";
            return;
        }
        // dvLoader.Visible = true;
        // lblStatus.Text = "Submit Clicked ";
        Common clsCommon = new Common();
        DataTable FortNight = new DataTable();
        FortNight = clsCommon.getFortNight(ddlfortNight.SelectedItem.Value.ToString());
        string processed = FortNight.Rows[0]["IsPusingPenalityCaliculated"].ToString();
        string rtpenality = FortNight.Rows[0]["rtPenlity"].ToString();
        string InspectionPenality = FortNight.Rows[0]["InspectionPenality"].ToString();
        string scheduledpenality = FortNight.Rows[0]["scheduledpenality"].ToString();
        string gpspenality = FortNight.Rows[0]["gpspenality"].ToString();
        string id = FortNight.Rows[0]["id"].ToString();
        string numberoftrips = FortNight.Rows[0]["numberoftrips"].ToString(); 
        DateTime to_Date = Convert.ToDateTime(FortNight.Rows[0]["to_date"].ToString());
        string month = FortNight.Rows[0]["monthID"].ToString();
        string Year = FortNight.Rows[0]["yearid"].ToString();
        if (processed == "0")
        {
            // lblStatus.Text = // lblStatus.Text + " Inserting Fresh Data for current Fortnight Started ;";
            clsCommon.insertDataOFFortnight(id, month, Year, FortNight.Rows[0]["fid"].ToString());
            // lblStatus.Text = // lblStatus.Text + " Inserting Fresh Data for current Fortnight Completed -- Caliculation Started ;";
            // processData(id);
            // bindData(id);
        }
        if (rtpenality == "0")
        {
            // lblStatus.Text = // lblStatus.Text + " Caliculating Response Time Penality ;";
            CaliculateRtPenality(id);
            clsCommon.updateStatus(id, "rtPenlity");
        }
        if (numberoftrips == "0")
        {
            DateTime dtFromDate = Convert.ToDateTime(FortNight.Rows[0]["from_date"].ToString());
            DateTime dtToDate = Convert.ToDateTime(FortNight.Rows[0]["to_date"].ToString());
            // lblStatus.Text = // lblStatus.Text + " Caliculating Response Time Penality ;";
            CaliculatenumberoftripsPenality(id, dtFromDate.ToString("yyyy-MM-dd"), dtToDate.ToString("yyyy-MM-dd"));
            clsCommon.updateStatus(id, "numberoftrips");
        }
        if (InspectionPenality == "0")
        {
            // lblStatus.Text = // lblStatus.Text + " Caliculating Inspection App Penality ;";
            caliculateInspectionPenality(id);
            clsCommon.updateStatus(id, "InspectionPenality");
        }
        if (scheduledpenality == "0")
        {
            // lblStatus.Text = // lblStatus.Text + " Caliculating Scheduled Penality ;";
            caliculateschpenality(id);
            clsCommon.updateStatus(id, "scheduledpenality");
        }
        if (gpspenality == "0")
        {
            // lblStatus.Text = // lblStatus.Text + " Caliculating GPS Penality ;";
            caliculateGpsPenality(id);
            clsCommon.updateStatus(id, "gpspenality");
        }
        // lblStatus.Text = // lblStatus.Text + " All Penalities Are Caliculated ;";

        lblid.Text = id;

       // string id = ddlfortNight.SelectedItem.Value.ToString();
        string dist = ddlDistrict.SelectedItem.Value.ToString();
        bindData(id, dist);
    }

    private void CaliculatenumberoftripsPenality(string id, string from_date, string to_date)
    {
        Common clsCommon = new Common();
        string Amount104 = ConfigurationSettings.AppSettings["Amount104"]; //ConfigurationManager.ConnectionStrings["Amount104"].ConnectionString.ToString();
        int vehCount = 586;
        int round = 2;
        float minTrips = float.Parse("4.00");
        int vehType = 104 ;
        int vehType_PenalityAll = 2;
        DataTable dtNoOfTrips = new DataTable();
        dtNoOfTrips = clsCommon.getData_NumberofTrips(from_date, to_date, Amount104, vehCount,round, minTrips, vehType );
        if(dtNoOfTrips.Rows.Count <=0)
        {
            Show("Something went wrong");
            return;
        }

        else
        {
            float amountForNumberOfTrips = float.Parse(dtNoOfTrips.Rows[0]["trips"].ToString());
            clsCommon.updateData(id, amountForNumberOfTrips,vehType_PenalityAll);

        }

    }
    public void Show(string message)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "msg", "alert('" + message + "');", true);
    }
}