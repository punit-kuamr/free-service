﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="_Default" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <link href="css/gridviewScroll.css" rel="stylesheet" />
    <style type="text/css">
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            background-color: black;
            z-index: 99;
            opacity: 0.8;
            filter: alpha(opacity=80);
            -moz-opacity: 0.8;
            min-height: 100%;
            width: 100%;
        }

        .gridview td {
            padding: 10px;
        }

        .gridview tr {
            padding: 2px;
        }

        .gridview th {
            padding: 10px;
        }

        .loading {
            font-family: Arial;
            font-size: 10pt;
            /*border: 5px solid #67CFF5;*/
            width: 200px;
            height: 100px;
            display: none;
            position: fixed;
            /*background-color: White;*/
            z-index: 999;
        }
    </style>
    <style type="text/css" media="screen">
        .pager a {
            border: 1px solid #EDF5FF;
            color: #0067A5;
            text-decoration: underline;
            padding: 2px 5px;
        }

        .pager span {
            background-color: #0067A5;
            border: 1px solid #DBEAFF;
            color: #FFFFFF;
            padding: 2px 5px;
        }

        .pager a:hover {
            color: #1E90FF;
        }

        .frozenHeader {
            font-size: 14px;
            font-weight: bold;
            text-align: center;
            /* background-color: White; */
            color: Black;
            border-right: 1px solid black;
            position: relative;
            cursor: default;
            top: expression(document.getElementById("gvCaseDetails").scrollTop-2);
            z-index: 10;
        }
    </style>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript">
        function ShowProgress() {
            setTimeout(function () {
                var modal = $('<div />');
                modal.addClass("modal");
                $('body').append(modal);
                var loading = $(".loading");
                loading.show();
                var top = Math.max($(window).height() / 2 - loading[0].offsetHeight / 2, 0);
                var left = Math.max($(window).width() / 2 - loading[0].offsetWidth / 2, 0);
                loading.css({ top: top, left: left });
            }, 200);
        }
        $('form').live("submit", function () {
            ShowProgress();
        });
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <table style="margin-left: 40px;">
        <tr>
            <%--<td style="width: 70px">Year
            </td>
            <td style="width: 150px">
                <asp:DropDownList ID="ddlYear" Style="width: 75%;" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlYear_SelectedIndexChanged">
                </asp:DropDownList>
            </td>
            <td style="width: 105px">Month
            </td>
            <td style="width: 140px">
                <asp:DropDownList ID="ddlMonth" Style="width: 75%;" runat="server" AutoPostBack="true" OnSelectedIndexChanged="ddlMonth_SelectedIndexChanged">
                </asp:DropDownList>
            </td>--%>
            <td style="width: 100px">Fort Night
            </td>
            <td style="width: 150px">
                <asp:DropDownList ID="ddlfortNight" runat="server" Style="width: 85%;">
                    <asp:ListItem Text="-- Select --" Value="0"></asp:ListItem>
                </asp:DropDownList>
            </td>
            <td>District&nbsp&nbsp&nbsp&nbsp
            </td>
            <td>
                <asp:DropDownList ID="ddlDistrict" runat="server"></asp:DropDownList>
            </td>
            <td></td>
            <td>&nbsp&nbsp&nbsp&nbsp</td>
            <td>
                <asp:Button runat="server" ID="btnBindData" Text="BindData" OnClick="btnBindData_Click"></asp:Button>
            </td>
            <%--<td>Submit
            </td>
            <td>
                <asp:Button runat="server" ID="btnSubmit" Text="Submit" OnClick="btnSubmit_Click" />
            </td>--%>
        </tr>
        <tr>
        </tr>

        <tr></tr>


        <tr>
            <td>Push Data
            </td>
            <td>
                <asp:Button runat="server" ID="btnPush" Text="Submit" OnClick="btnPush_Click" />
            </td>
        </tr>
        <tr>
            <td>Status
            </td>
            <td>
                <asp:Label ID="lblStatus" runat="server"></asp:Label>
            </td>
            <td>
                <asp:Label ID="lblid" runat="server" Visible="false"></asp:Label>
            </td>
        </tr>

    </table>
    <div class="loading" align="center">
        <img src="images/quiz-loading.gif" alt="" />
    </div>
    <div style="margin-left: 2%; margin-top: 1%;">
        <asp:GridView ID="grdData" runat="server" Font-Names="Arial" OnPageIndexChanging="grdData_PageIndexChanging" CssClass="gridview"
            Font-Size="11pt" HeaderStyle-BackColor="#993300" HeaderStyle-ForeColor="White" HeaderStyle-CssClass="gridview" RowStyle-HorizontalAlign="Center" PagerStyle-VerticalAlign="Middle" AllowPaging="true" PageSize="10">
            <PagerStyle CssClass="GridviewScrollPager" />
        </asp:GridView>
    </div>

</asp:Content>

